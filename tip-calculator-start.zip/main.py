#If the bill was $150.00, split between 5 people, with 12% tip. 
# Greating Welcome to tip calculator
print("Welcome to the tip calculator!")
# Getting the input from the User
Total_bill=input("What was the total bill?")
totalBill1=float(Total_bill)
# print(totalBill1)
Total_tip=input("How much tip would you like to give? 10, 12, or 15?")
total_tip_inint=int(Total_tip)
# print(total_tip_inint)
People_to_split=input("How many people to split the bill?")
total_people_split=int(People_to_split)
# print(total_people_split)

total_percentage=(totalBill1*total_tip_inint)/100
# print(total_percentage)
toatl_sum_Bill=totalBill1+total_percentage
# print(toatl_sum_Bill)
split_wise=toatl_sum_Bill/total_people_split
# print(split_wise)
each_person_pay=round(split_wise,2)
# print(round(split_wise,2))
each_person_pay="{:.2f}".format(split_wise)
print(f"Each person should pay: {each_person_pay}")
#Format the result to 2 decimal places = 33.60

#Tip: There are 2 ways to round a number. You might have to do some Googling to solve this.💪

#Write your code below this line 👇